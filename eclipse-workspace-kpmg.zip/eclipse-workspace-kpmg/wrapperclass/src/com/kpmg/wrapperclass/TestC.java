package com.kpmg.wrapperclass;

public class TestC {
	public static void main(String[] args) {
		
		String a = "true";
		
		boolean r = Boolean.parseBoolean(a);
		System.out.println(r);
		
	}
}
