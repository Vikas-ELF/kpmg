package com.kpmg.wrapperclass;

public class TestB {
	public static void main(String[] args) {
		
		String a = "90";
		String b = "60";
		
		String k = "4.56";
		
		System.out.println( a + b );
		
		
		//parsing
		
		int i = Integer.parseInt(a);
		
		int j = Integer.parseInt(b);
		
		double r = Double.parseDouble(k);
		System.out.println(r+1);
		
		System.out.println( i + j );
	}
}
