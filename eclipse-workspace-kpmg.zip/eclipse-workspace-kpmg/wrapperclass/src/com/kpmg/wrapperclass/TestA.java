package com.kpmg.wrapperclass;

public class TestA {
	public static void main(String[] args) {
		
		int i = 10;
		Integer k = new Integer(i);//boxing
		
		Double m = new Double(24.6);
		double r = m.doubleValue();//un-boxing
		
		int y = 90;
		Integer t = 100;//auto-boxing
		
		double p = m;//auto-unboxing
		
		
		System.out.println(r);
		
		System.out.println(k + 90);
		
		
	}
}
