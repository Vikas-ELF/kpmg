package com.kpmg.string;

public class TestK {
	public static void main(String[] args) {
		
		
		StringBuilder sb = new StringBuilder();
		sb.append("Ramu");
		
		System.out.println(sb);
		
		
		StringBuilder sm = new StringBuilder("Ramya");
		
		System.out.println(sm);
		
	}
}
