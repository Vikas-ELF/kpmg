package com.kpmg.string;

public class TestA {
	public static void main(String[] args) {
		
		//1
		String s = "Anil";
		
		//2
		String h = new String("Simran");
		
		
		
		
		
		
	}
}
