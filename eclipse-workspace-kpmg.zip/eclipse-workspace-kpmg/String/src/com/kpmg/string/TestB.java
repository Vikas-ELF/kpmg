package com.kpmg.string;

public class TestB {
	public static void main(String[] args) {
		
		String a = "Divya";
		
		
		int count = a.length();
		
		System.out.println(count);
		
	}
}
