package com.kpmg.string;

public class TestJ {
	public static void main(String[] args) {
		
		
		StringBuffer sb = new StringBuffer();
		sb.append("Ramu");
		
		System.out.println(sb);
		
		
		StringBuffer sm = new StringBuffer("Ramya");
		
		System.out.println(sm);
		
	}
}
