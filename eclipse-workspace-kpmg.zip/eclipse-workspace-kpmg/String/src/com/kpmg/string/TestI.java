package com.kpmg.string;

public class TestI {
	public static void main(String[] args) {
		String k = "Ramu";
		String p ="ramu";
		
		
		System.out.println( k.equals(p) );
		
		System.out.println(k.equalsIgnoreCase(p));
	}
}
