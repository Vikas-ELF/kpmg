package com.kpmg.string;

public class TestF {
	public static void main(String[] args) {
		String userId = "Divya J".trim();
		
		
		
		userId = userId.trim();
		
		validate(userId);
		
		boolean res = userId.equals("Divya J");
		
		System.out.println(res);
		
	}
	
	static void validate(String userId) {
		
	}
}
