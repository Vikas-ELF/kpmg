package com.kpmg.string;

public class TestG {
	public static void main(String[] args) {
		
		String k = "Ravi";
		
		char ch[] = k.toCharArray();
		
		for(int i =0;i<ch.length;i++) {
			System.out.println(ch[i]);
		}
		
		
	}
}
