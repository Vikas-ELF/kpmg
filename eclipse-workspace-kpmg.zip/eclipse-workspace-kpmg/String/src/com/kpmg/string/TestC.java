package com.kpmg.string;

public class TestC {
	public static void main(String[] args) {
		
		String a = "Divya";
		
		char r = a.charAt(0);
		System.out.println(r);

		
		char t = a.charAt(100);
		System.out.println(t);
	}
}
