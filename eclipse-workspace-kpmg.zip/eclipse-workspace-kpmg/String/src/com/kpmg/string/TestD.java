package com.kpmg.string;

public class TestD {
	public static void main(String[] args) {
		String a = "A";
		char c = a.charAt(0);
		System.out.println(c);
	}
}
