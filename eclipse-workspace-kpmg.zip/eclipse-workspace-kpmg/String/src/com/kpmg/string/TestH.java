package com.kpmg.string;

public class TestH {
	public static void main(String[] args) {
		String k = "hi how are you";
		
		String sa[] = k.split(" ");
		
		for(int i=0;i<sa.length;i++) {
			
			System.out.println(sa[i]);
			
		}
	}
}
