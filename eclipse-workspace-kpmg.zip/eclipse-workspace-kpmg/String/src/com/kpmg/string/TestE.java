package com.kpmg.string;

public class TestE {
	public static void main(String[] args) {
		
		String a = "Divya";
		
		a = a.toUpperCase();
		
		
		System.out.println(a);
		
	}
}
