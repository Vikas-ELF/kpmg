package com.kpmg.thread;

public class TestA {
	public static void main(String[] args) {
		
		Mobile m1 = new Mobile();
		m1.start();
		
		Mobile m2 = new Mobile();
		m2.start();
		
		Mobile m3 = new Mobile();
		m3.start();
	}
}
