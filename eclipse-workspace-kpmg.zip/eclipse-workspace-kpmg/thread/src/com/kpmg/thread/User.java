package com.kpmg.thread;

public class User extends Thread {
	
	BMS a;

	public User(BMS a) {
		this.a = a;
	}
	
	@Override
	public void run() {
		a.book();
		
	}
	
}
