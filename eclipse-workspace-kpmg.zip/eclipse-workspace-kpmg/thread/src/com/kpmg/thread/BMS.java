package com.kpmg.thread;

public class BMS {
	
	synchronized void book() {
		for(int i=0;i<5;i++) {

			System.out.println(i);

			

		}
	}
}
