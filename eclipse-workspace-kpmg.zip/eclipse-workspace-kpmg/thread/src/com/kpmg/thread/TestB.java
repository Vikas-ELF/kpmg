package com.kpmg.thread;

public class TestB {
	public static void main(String[] args) {
		
		BMS ref = new BMS();
		
		User t1 = new User(ref);
		
		User t2 = new User(ref);
		
		User t3 = new User(ref);
		
		t1.start();
		t2.start();
		t3.start();
	}
}
