package com.kpmg.exception;

public class CashValidator {
	
	void validate(int amount) throws TransactionLimitException {
		if(amount > 20000) {
			TransactionLimitException ti = new TransactionLimitException();
			throw ti;
		}
	}
	
}
