package com.kpmg.exception;

public class TestG {
	public static void main(String[] args) {
		System.out.println("main started");
		PayTm p = new PayTm();
		try {
			p.book();
		}catch(ArithmeticException e) {
			System.out.println("Exception caught at main");
		}
		System.out.println("main ended");
	}
}
