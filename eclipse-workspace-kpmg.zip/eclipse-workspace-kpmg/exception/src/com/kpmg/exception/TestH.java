package com.kpmg.exception;

import java.io.File;
import java.io.IOException;

public class TestH {
	public static void main(String[] args) {
		File f = new File("P:/vikas.txt");

		try {
			
			f.createNewFile();
			System.out.println("Created the file");
			
		}catch(IOException e) {
			System.out.println("Sorry not able to create the file");
		}
	}
}
