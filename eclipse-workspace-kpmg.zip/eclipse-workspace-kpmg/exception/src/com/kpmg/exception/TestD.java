package com.kpmg.exception;

public class TestD {
	public static void main(String[] args) {

		System.out.println("Main started");

		try {
			System.out.println(10/0);
			System.out.println("thank you");
			System.out.println("Bye bye");
		} 
		catch(ArithmeticException ae) {
			System.out.println("Dont devide by zero");
		}
		

		System.out.println("Main ended");
	}
}
