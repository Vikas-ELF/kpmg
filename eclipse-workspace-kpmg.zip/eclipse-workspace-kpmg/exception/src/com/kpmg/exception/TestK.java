package com.kpmg.exception;

public class TestK {
	public static void main(String[] args) {
		
		System.out.println("main started");
		
		CashValidator cv = new CashValidator();
		
		try {
			cv.validate(25000);
			System.out.println("give cash");
		} catch (TransactionLimitException e) {
			e.printStackTrace();
		}
		
		
		System.out.println("main ended");
	}
}
