package com.kpmg.exception;

import java.util.InputMismatchException;

public class TestF {
	public static void main(String[] args) {
		
		System.out.println("Main started");
		int a[] = new int[3];
		
		try {
			Integer.parseInt("3");
			a[5] = 10;
			System.out.println(10/0);
		} catch(ArithmeticException | NumberFormatException | ArrayIndexOutOfBoundsException ae) {
			
			ae.printStackTrace();
		}  catch(NullPointerException | InputMismatchException in) {
			String mesg = in.getMessage();
			System.out.println(mesg);
		}
		
		System.out.println("Main ended");
	}
}
