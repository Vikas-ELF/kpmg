package com.kpmg.exception;

public class TransactionLimitException extends Exception {
	String message = "Your day lemit is only 20k";
	
	public TransactionLimitException() {
	}

	public TransactionLimitException(String message) {
		this.message = message;
	}
	
	@Override
	public String getMessage() {
		return message;
	}
}
