package com.kpmg.exception;

public class PayTm {
	void book() {
		System.out.println("book started");
		
		IRCTC i = new IRCTC();
		try {
		i.confirm();
		}catch(ArithmeticException ae) {
			System.out.println("Exception caught at book");
		}
		System.out.println("book ended");
	}
}
