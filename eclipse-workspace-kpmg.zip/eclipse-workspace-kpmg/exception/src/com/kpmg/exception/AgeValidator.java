package com.kpmg.exception;

public class AgeValidator {
	
	void validate(int age) {
		
		
		if(age < 18) {
			InvalidAgeException ref = new InvalidAgeException("Your age is still "+age);
			throw ref;
		}
		
	}
	
	
}
