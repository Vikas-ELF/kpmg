package com.kpmg.exception;

public class TestE {
	public static void main(String[] args) {
		System.out.println("Main started");

		String name = null;
		int[] a = new int[3];
		
		try {
			Integer.parseInt("3.4");
			a[5] = 10;
			System.out.println(10/2);
			System.out.println(name.length());
			
		} catch(ArithmeticException ae) {
			System.out.println("Dont devide by zero");
		} catch(NullPointerException ne) {
			System.out.println("Dont deal with null");
		} catch(ArrayIndexOutOfBoundsException ai) {
			System.out.println("Dont cross array boundry");
		} catch(Exception e) {
			System.out.println("Genral catch block");
		}
		
		
		System.out.println("Main ended");
	}
}
