package com.kpmg.exception;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class TestL {
	public static void main(String[] args) {
		
		
 		
		try(Scanner sc = new Scanner(System.in);
			FileOutputStream fout = new FileOutputStream("vikas.txt")	
				) {
			
			String name = sc.nextLine();
			int age = sc.nextInt();
			double height = sc.nextDouble();
			
			
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
		
	}
}
