package com.kpmg.exception;

public class TestB {
	public static void main(String[] args) {
		System.out.println("Main started");

		String k = "Ramu";
		try {
			
			System.out.println(  k.length()  );
			
		} catch(NullPointerException e) {
			
			System.out.println("Dont deal with null");
		
		}
		System.out.println("Main ended");
	}
}
