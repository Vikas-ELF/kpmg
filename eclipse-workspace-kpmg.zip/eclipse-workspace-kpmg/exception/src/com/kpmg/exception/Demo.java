package com.kpmg.exception;

import java.io.File;
import java.io.IOException;

public class Demo {

	void create() {

		File f = new File("vikas.txt");
		
		try {
			f.createNewFile();
		}catch(IOException e) {
			System.out.println("Sorry not able to create the file");
		}

	}

}
