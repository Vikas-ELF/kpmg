package com.kpmg.exception;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;

public class TestI {
	
	void create() throws IOException,ClassNotFoundException {

		File f = new File("vikas.txt");
		
		f.createNewFile();
		
		Class.forName("com.lanag.String");

	}

	
	public static void main(String[] args) throws ClassNotFoundException, IOException  {
		
		TestI i = new TestI();
		
		i.create();
		
	}
	
}
