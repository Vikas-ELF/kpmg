package com.kpmg.exception;

public class InvalidAgeException extends RuntimeException{
	
	private String message = "Your age is not valid";
	
	
	public InvalidAgeException() {
	}
	
	public InvalidAgeException(String message) {
		this.message = message;
	}


	@Override
	public String getMessage() {
		return message;
	}


	
}
