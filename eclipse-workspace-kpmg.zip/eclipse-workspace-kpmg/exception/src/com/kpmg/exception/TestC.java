package com.kpmg.exception;

public class TestC {
	public static void main(String[] args) {
		
		System.out.println("Main started");
		
		System.out.println(10/0);
		
		System.out.println("Main ended");
	}
}
