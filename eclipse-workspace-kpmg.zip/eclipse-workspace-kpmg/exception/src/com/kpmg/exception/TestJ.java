package com.kpmg.exception;

public class TestJ {
	public static void main(String[] args) {

		System.out.println("main started");
		AgeValidator av = new AgeValidator();
		
		try {
			av.validate(14);
			System.out.println("Open the door");
		}catch(InvalidAgeException a) {
			a.printStackTrace();
		}

		System.out.println("main ended");

	}
}
