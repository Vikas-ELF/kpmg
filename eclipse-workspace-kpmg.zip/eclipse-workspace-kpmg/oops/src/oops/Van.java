package oops;

public class Van {

	
	
	Van(int t) {
		
	}
	
	void move() {
		
	}
	
}
