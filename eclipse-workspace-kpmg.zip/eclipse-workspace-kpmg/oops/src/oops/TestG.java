package oops;

class D {
	int i = 90;
	
}







class E extends D {
	
	int i = 60;
	static int  j = 90;
	
	void m() {
		
		int i = 30;
		
		System.out.println("i is "+i);
		
		System.out.println("this.i is "+this.i);
		
		System.out.println("super.i is "+super.i);
	}
}


public class TestG {
	public static void main(String[] args) {
		
		E e = new E();
		e.m();
		
	}
}
