package oops;

public class TestW {
	public static void main(String[] args) {
		
		Shop s = new Shop();
		Pen r = s.getPen();
		
		Person p = new Person();
		p.recive(r);
	}
}
