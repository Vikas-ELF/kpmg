package oops;

public class Student {

	String name;
	int age;
	double height;


	public Student(String name, int age, double height) {
		this.name = name;
		this.age = age;
		this.height = height;
	}

	void display() {
		System.out.println("Name is "+name);
		System.out.println("Age is "+age);
		System.out.println("Height is "+height);
		System.out.println("----------------------------------");
	}
}
