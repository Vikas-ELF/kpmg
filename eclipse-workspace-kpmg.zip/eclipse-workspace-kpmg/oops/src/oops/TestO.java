package oops;


abstract class H {
	
	abstract void eat();
	abstract void walk();
	
	void run() {
		
	}
	
	void sit() {
		
	}
}

abstract class I extends H {
	void eat() {
		
	}
}

class J extends I {
	void walk() {
		
	}
}

public class TestO {

}
