package oops;

class MyBike {
	static final void move() {
		System.out.println("move bike");
	}
}

class Cycle extends MyBike{
	
	Cycle() {
		
	}
}


public class TestL {
	public static void main(String[] args) {
		
		Cycle c = new Cycle();
		
		c.move();
	}
}
