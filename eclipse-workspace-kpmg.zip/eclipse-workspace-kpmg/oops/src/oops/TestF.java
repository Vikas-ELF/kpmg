package oops;

class A {
	//1
	A() {
		System.out.println("I am A()");
	}
	//2
	A(int i) {
		System.out.println("I am A(int i)");
	}
}

class B extends A {
	//3
	B() {
		super();
		System.out.println("I am B()");
	}
	//4
	B(double e) {
		System.out.println("I am B(double e)");
	}
}


public class TestF {
	public static void main(String[] args) {
		new B();
	}
}
