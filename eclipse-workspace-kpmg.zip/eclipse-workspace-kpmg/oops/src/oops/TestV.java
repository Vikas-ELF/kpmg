package oops;

public class TestV {

	public static void main(String[] args) {
		
		Pen a = new Pen();
		
		Person r = new Person();
		
		r.recive(a);
		
		
	}
	
}
