package oops;

class Watch {
	
	Watch() {
		this(5);
		System.out.println("I am Watch()");
	}
	
	Watch(int i) {
		this(4.5);
		System.out.println("I am Watch(int i)");
	}
	
	Watch(double  i) {
		System.out.println("I am Watch(double i)");
	}
	
	Watch(int i,int j) {
		System.out.println("I am Watch(int i,int j)");
	}
}


public class TestE {
	public static void main(String[] args) {
		new Watch();
	}
}
