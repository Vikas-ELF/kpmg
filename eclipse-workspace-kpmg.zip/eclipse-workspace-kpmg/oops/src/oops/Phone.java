package oops;

public class Phone {
	
	Phone() {
		System.out.println("I am a constructor");
	}

	Phone(int t) {
		
	}
}
