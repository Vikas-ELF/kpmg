package oops;

public class TestH {
	public static void main(String[] args) {
		
		
		
		Student s1 = new Student("Priya",24,6.5);
		Student s2 = new Student("Dimple",15,4.5);

		s1.display();
		s2.display();
		
		
	}
}
