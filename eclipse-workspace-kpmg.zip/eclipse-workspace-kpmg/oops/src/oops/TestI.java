package oops;


class Tiger {
	
	final int i = 90;
	
	static final int j = 100;
	
	void eat( final int a,final int b) {
		System.out.println("a is "+a);
		System.out.println("b is "+b);
	}
	
	
}

public class TestI {
	public static void main(String[] args) {
		Tiger t = new Tiger();
		t.eat(50, 30);
	}
}
