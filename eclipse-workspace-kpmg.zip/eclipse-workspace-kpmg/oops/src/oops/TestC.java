package oops;

class Animal {
	//1
	Animal() {
		System.out.println("I am Animal()");
	}
	
	//2
	Animal(int i) {
		System.out.println("I am Animal(int i)");
	}
	
}
class Cow extends Animal{
	
	//3
	Cow() {
		System.out.println("I am Cow()");
	}
	
	//4
	Cow(int i) {
		super(10);
		System.out.println("I am Cow(int i)");
	}
}


public class TestC {
	public static void main(String[] args) {
		
		new Cow(10);
		
	}
}
