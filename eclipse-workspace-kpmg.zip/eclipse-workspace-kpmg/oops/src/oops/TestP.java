package oops;


abstract class K {
	
	int runKm;
	
	static int sum = 100;
	
	final int run = 90;
	
	private int y = 90;
	
	final void eat() {
		
	}
	
	static void wash() {
		
	}
	
	abstract void m();
	
	
	
}



public class TestP {

}
