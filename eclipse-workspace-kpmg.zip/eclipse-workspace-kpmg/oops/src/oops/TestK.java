package oops;

final class Lion {
	void eat() {
		//pizza
	}
}

class Cub {
	
}


public class TestK {
	public static void main(String[] args) {
		
		Lion r = new Lion();
		r.eat();
		
		
	}
}
