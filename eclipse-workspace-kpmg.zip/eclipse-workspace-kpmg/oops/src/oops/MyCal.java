package oops;

public interface MyCal {
	void add();

	default void sub() {

	}

	default void sub1() {

	}
	default void sub2() {

	}
	static void div() {

	}

	static void div2() {

	}
}
