package oops;

class Apple {
	
	final int cost;
	
	Apple() {
		cost = 90;
	}
	
	Apple(int i) {
		cost = 100;
	}
	
}

public class TestJ {

}
