package oops;

 interface Zen {
	 int sum = 100;
	 
	 
	 void move();
}

 class Alto implements Zen {
	 public void move() {
		 
	 }
 }

public class TestQ {
	
	public static void main(String[] args) {
		
		
		System.out.println(Zen.sum);
		
	}
	
	
}
