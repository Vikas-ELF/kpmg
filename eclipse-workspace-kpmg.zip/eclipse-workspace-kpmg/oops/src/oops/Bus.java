package oops;

public class Bus {
	
	
	//zero parametarised
	Bus() {
		System.out.println("I am Bus()");
	}
	
	//parametarised constructore
	Bus(int i) {
		System.out.println("I am Bus(int i)");
	}
	
	Bus(double d) {
		System.out.println("I am Bus(double d)");
	}
	
	Bus(int i, int j) {
		System.out.println("I am Bus(int i,int j)");
	}
}
