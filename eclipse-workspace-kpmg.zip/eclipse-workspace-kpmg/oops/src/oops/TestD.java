package oops;


class Bike {
	
	Bike(int i) {
		
	}
	
	Bike() {
		
	}
	void ride() {
		
	}
	
}


public class TestD {
	public static void main(String[] args) {
		
		
		Bike b = new Bike();
		b.ride();
		
		
	}
}
