package oops;

public class TestM {
	public static void main(String[] args) {
		
		
		new Frog();
		
		
	}
}
