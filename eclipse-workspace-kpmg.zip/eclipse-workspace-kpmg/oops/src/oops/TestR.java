package oops;

interface Road {
	void roadTax();
}

interface Property {
	void propertyTax();
}


class TaxCal implements Road, Property{

	@Override
	public void roadTax() {
		
	}

	@Override
	public void propertyTax() {
		
	}
	
}

class Dog {
	void eat () {
		
	}
}

abstract class Puppy extends Dog implements Road,Property{

	
	
}


public class TestR {

}
