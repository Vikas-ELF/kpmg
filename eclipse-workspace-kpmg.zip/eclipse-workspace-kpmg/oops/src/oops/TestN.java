package oops;

abstract class F {
	
	abstract void eat();
	abstract void walk();
	
	void run() {
		
	}
	
	void sit() {
		
	}
}

class G extends F {
	void eat() {
		
	}
	
	void walk() {
		
	}
}

public class TestN {

}
