package oops;

public abstract class Fish {

	
	void swim() {
		
	}
	abstract void drink();
	
}


class Frog  extends Fish {
	void drink() {
		
	}
}


