package oops;

public class Pen {
	void write() {
		System.out.println("I am write() method");
	}
}
