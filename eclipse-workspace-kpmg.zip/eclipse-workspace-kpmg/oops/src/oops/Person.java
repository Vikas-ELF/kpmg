package oops;

public class Person {
	
	
	void recive(Pen p) {
		p.write();
	}
	
}
