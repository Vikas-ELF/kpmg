package oops;

public abstract class GenricServlet {
	abstract void doGet();
	abstract void doPost();
	
	void getConfig() {
		
	}
}
