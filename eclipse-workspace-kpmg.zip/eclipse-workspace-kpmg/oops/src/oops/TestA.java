package oops;



public class TestA {
	public static void main(String[] args) {
		
		new Bus(10,15);
		
	}
}
