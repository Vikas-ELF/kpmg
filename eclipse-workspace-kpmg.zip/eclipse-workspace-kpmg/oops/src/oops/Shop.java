package oops;

public class Shop {
	
	Pen getPen() {
		Pen p = new Pen();
		return p;
	}
	
}
