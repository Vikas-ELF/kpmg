package oops;

public class HttpServlet extends GenricServlet {

	@Override
	void doGet() {
		System.out.println("I am doGet");
	}

	@Override
	void doPost() {
		System.out.println("I am doPost");
	}
	
	

}
