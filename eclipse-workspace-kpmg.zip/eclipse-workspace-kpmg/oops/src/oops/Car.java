package oops;

public class Car extends Van {
	
	Car() {
		super(10);
	}
	
	
	Car(String name) {
		super(90);
	}

}
