package oops;

interface M {
	void a();
	void b();
}

interface N {
	void t();
}

interface P {
	void s();
}

interface X extends M,N,P{
	
}


public class TestT {
	
}
