package com.kpmg.bean;

public class Hibernate {
	
	
	void save(Employee e) {
		String name = e.getName();
		int id = e.getId();
		double height = e.getHeight();
		
		System.out.println("Name is "+name);
		System.out.println("ID id "+id);
		System.out.println("Height is "+height);
		System.out.println("---------------------------");
	}
	
	
}
