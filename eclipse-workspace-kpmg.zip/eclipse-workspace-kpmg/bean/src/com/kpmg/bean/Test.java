package com.kpmg.bean;

public class Test {
	public static void main(String[] args) {
		
		Employee a = new Employee();
		a.setId(1);
		a.setName("Ramya");
		a.setHeight(4.9);

		
		Hibernate h = new Hibernate();
		
		h.save(a);
		
	}
}
