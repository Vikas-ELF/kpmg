package casting;

class Animal {
	void eat() {
		System.out.println("eat");
	}
}
class Cow extends Animal {
	void giveMilk() {
		System.out.println("giveMilk");
	}
}

class Lion extends Animal {
	void eatMeat() {
		System.out.println("eatmeat");
	}
}



public class TestC {
	public static void main(String[] args) {
		
		Animal a = new Cow();
		a.eat();
		
		if( a instanceof Cow) {
			Cow c = (Cow)a;
			c.giveMilk();
		} else if( a instanceof Lion) {
			Lion r = (Lion)a;
			r.eatMeat();
		}
		
		
		
	}
}
