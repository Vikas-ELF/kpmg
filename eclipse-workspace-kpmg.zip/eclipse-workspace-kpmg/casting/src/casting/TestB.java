package casting;

class Father {
	void home() {
		System.out.println("i am home()");
	}
}

class Son extends Father {
	
	void car() {
		System.out.println("i am car()");
	}
}


public class TestB {
	public static void main(String[] args) {
		
		Father f = new Son();//up-casting
		
		Son s = (Son)f;//down-casting
		
		s.home();
		s.car();
		
		
	}
}
