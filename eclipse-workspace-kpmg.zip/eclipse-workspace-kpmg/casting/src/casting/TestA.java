package casting;

public class TestA {
	public static void main(String[] args) {
		
		int a = 10;
		double t = (double)a;
		
		
		System.out.println(t);

		
		double m = 9.56;
		int e = (int)m;
		
		System.out.println(e);
		
	}
}
