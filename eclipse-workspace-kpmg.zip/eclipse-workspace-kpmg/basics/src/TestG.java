
public class TestG {
	public static void main(String[] args) {
		
		Cow c = new Cow();
		c.eat();
		c.walk();
		
		Lion r = new  Lion();
		r.eat();
		r.run();
		
	}
}
