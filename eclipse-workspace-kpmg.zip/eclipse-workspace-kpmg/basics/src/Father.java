
public class Father {
	
	int cost;
	
	void bike() {
		System.out.println("OLD CD-100");
	}
}
