
public class BMICalculator {
	
	double height;
	double weight;
	
	double getBmi() {
		return weight/(height*height);
	}
	
	String getResult(double bmi) {
		if(bmi < 18) {
			return "Under weight";
		} else if(bmi >=18 && bmi <=24) {
			return "Normal";
		} else if(bmi >24 && bmi <=30) {
			return "Over weight";
		} else {
			return "Obase";
		}
	}
}
