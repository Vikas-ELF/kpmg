
public class Calculator {
	
	void add() {
		System.out.println("I am add()");
	}
	
	void sub() {
		System.out.println("I am sub()");
	}
}
