
public class GenThree extends GenTwo{
	
	void camera() {
		System.out.println("I am a camera()");
	}
}
