
public class Van {
	
	int cost;
	static int size;
	
	
	
	void read() {
		
	}
	
	static void write() {
		
	}
}
