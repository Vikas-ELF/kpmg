
public class Cow extends Animal{
	void walk() {
		System.out.println("I am walk()");
	}
}
