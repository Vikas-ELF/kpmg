
public class Lion extends Animal {
	void run() {
		System.out.println("I am run()");
	}
}
