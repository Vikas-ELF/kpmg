public class TestB {
	public static void main(String[] args) {
		
		BMICalculator b = new BMICalculator();
		b.height = 5.76;
		b.weight = 67.5;
		
		double bmiResult = b.getBmi();
		
		System.out.println("BMI result is "+bmiResult);
		
	}
}
