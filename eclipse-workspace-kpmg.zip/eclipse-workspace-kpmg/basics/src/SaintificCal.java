
public class SaintificCal  extends Calculator {
	
	
	void sin() {
		System.out.println("I a sin()");
	}
}
