package basics;

class LevelOne {
	
	void move() {
		System.out.println("0-100KMPh");
	}
	
}
class LevelTwo extends LevelOne {
	
	void move() {
		System.out.println("0-200KMPh");
	}
	
}

class LevelThree extends LevelTwo {
	
	
	
}
public class TestI {
	public static void main(String[] args) {
		
		LevelOne f = new LevelThree();
		f.move();
		
	}
}

