
public class GenOne {
	
	void call() {
		System.out.println("I am a call()");
	}
	
	void mesg() {
		System.out.println("I am a mesg()");
	}
}
