
public class TestH {
	public static void main(String[] args) {

		
		Father f= new Son();
		f.bike();
		
		
	}
}
