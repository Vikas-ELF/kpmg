
public class GenTwo extends GenOne{
	void radio() {
		System.out.println("I am a radio()");
	}
	
}
