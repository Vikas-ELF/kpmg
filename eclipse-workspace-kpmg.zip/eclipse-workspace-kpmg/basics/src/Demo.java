
public class Demo {

	
	char grade(double per) {
		
		if(per > 70) {
			return 'A';
		} else if(per >= 60 ) {
			return 'B';
		} else if(per >= 50) {
			return 'C';
		} else {
			return 'D';
		}
	}
	
	
	
	static int add(int a,int b) {
		return a + b;
	}

	void gm() {
		System.out.println("Good morniung");
		return;
	}
	
	public static void main(String[] args) {
	
		int t =  add(10,15);
		
		System.out.println("hi");
	}
}
