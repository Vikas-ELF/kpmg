
public class Son extends Father {
	
	int size;
	
	void bike() {
		System.out.println("Modifed Biked");
	}
}
