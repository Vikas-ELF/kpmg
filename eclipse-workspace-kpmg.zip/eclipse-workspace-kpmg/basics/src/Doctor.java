
public class Doctor {
	int doctorPatientCount;
	static int organisationCount;
	
	void swipe() {
		doctorPatientCount++;
		organisationCount++;
	}
}
