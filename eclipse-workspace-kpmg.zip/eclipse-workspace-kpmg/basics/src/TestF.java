
public class TestF {
	public static void main(String[] args) {
		
		GenThree t = new GenThree();
		t.call();
		t.mesg();
		t.radio();
		t.camera();
		
		GenTwo s = new GenTwo();
		s.call();
		s.mesg();
		s.radio();
		
		GenOne f = new GenOne();
		f.call();
		f.mesg();
		
		
	}
}
