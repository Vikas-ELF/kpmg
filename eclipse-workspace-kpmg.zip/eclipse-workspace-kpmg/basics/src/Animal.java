
public class Animal {
	void eat() {
		System.out.println("I am eat()");
	}
}
