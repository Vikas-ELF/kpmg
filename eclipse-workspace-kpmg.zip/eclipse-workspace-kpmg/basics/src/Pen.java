
public class Pen {
	
	int cost;
	
	void write() {
		System.out.println("I am a write method");
	}
	
	
}
