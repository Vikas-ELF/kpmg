
public class TestE {
	public static void main(String[] args) {
		
		SaintificCal s = new SaintificCal();
		s.add();
		s.sub();
		s.sin();
		
		
		Calculator c = new Calculator();
		c.add();
		c.sub();
		
		
	}
}
