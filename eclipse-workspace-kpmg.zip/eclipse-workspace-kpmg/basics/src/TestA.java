
public class TestA {
	public static void main(String[] args) {
		
		Pen a = new Pen();
		
		a.cost = 100;
		a.write();
		
	}
}
