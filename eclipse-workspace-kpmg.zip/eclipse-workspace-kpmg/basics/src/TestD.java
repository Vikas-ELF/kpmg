
public class TestD {
	public static void main(String[] args) {
		Doctor a = new Doctor();
		Doctor b = new Doctor();
		Doctor c = new Doctor();
		
		a.swipe();
		b.swipe();
		a.swipe();
		c.swipe();
		a.swipe();
		b.swipe();
		
		System.out.println("Doctor A count "+a.doctorPatientCount);
		System.out.println("Doctor B count "+b.doctorPatientCount);
		System.out.println("Doctor C count "+c.doctorPatientCount);
		
		System.out.println("Total is "+Doctor.organisationCount);
	}
}
