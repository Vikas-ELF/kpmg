package com.kpmg.objectclass;

public class TestA {
	public static void main(String[] args) {
		
		String s = new String("divya");
		String p = new String("divya");
		
		
		System.out.println(  s.equals(p)    );
		
		
		
	}
}
