package com.kpmg.objectclass;

public class TestB {
	public static void main(String[] args) {
		
		Student s = new Student();
		s.id = 1;
		s.name = "Anil";
		s.percentage = 78.6;
		
		Student s2 = new Student();
		s2.id = 1;
		s2.name = "Anil";
		s2.percentage = 78.6;
		
		
		System.out.println(  s.equals(s2)    );
		
		
	}
}
