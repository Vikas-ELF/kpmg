package com.kpmg.objectclass;

public class Test {
	public static void main(String[] args) {
		
		Student s = new Student();
		s.id = 1;
		s.name = "Anil";
		s.percentage = 78.6;
		
		System.out.println(s);
		
		
	}
}
