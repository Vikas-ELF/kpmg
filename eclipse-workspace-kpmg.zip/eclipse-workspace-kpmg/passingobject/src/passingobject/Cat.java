package passingobject;

public class Cat extends Animal {

	

}
