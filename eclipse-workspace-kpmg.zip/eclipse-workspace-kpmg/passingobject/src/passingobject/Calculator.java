package passingobject;

public class Calculator {

	void add() {

	}

	void add(double t) {

	}


	void add(int i) {

	}

	
	void add(int i,int j) {

	}
}
