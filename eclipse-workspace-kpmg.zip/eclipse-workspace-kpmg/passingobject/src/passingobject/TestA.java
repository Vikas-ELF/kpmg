package passingobject;

import java.util.Scanner;

public class TestA {
	public static void main(String[] args) {
		Animal a = null;
		System.out.println("Enter the option");
		Scanner scan = new Scanner(System.in);
		int opt = scan.nextInt();
		if(opt == 1) {
			a = new Cow();
		} else if(opt ==2 ) {
			a = new Lion();
		}
		
		a.eat();
	}
}
