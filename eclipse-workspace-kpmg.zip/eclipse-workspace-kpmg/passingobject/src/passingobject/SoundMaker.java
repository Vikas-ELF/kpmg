package passingobject;

public class SoundMaker {
	
	
	void makeSound(Animal c) {
		c.eat();
	}
	
}
