package passingobject;

public class Train {
	void search(String name) {
		
	}
	
	void search(int number) {
		
	}
}
