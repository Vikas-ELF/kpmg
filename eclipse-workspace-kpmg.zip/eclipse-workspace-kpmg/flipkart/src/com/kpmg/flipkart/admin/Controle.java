package com.kpmg.flipkart.admin;

public class Controle {
	
	public void getStats() {
		System.out.println("I am getStats method");
	}
	
}
