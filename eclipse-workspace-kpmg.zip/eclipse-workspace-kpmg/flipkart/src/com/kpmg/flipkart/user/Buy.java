package com.kpmg.flipkart.user;

public class Buy {
	public void buyProduct() {
		System.out.println("I am a buyProduct()");
	}
	
	void a() {
		
	}
}
