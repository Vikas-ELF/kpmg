package com.kpmg.flipkart.user;


import com.kpmg.flipkart.admin.Controle;
import com.kpmg.flipkart.owner.AddProduct;
import com.kpmg.flipkart.owner.EditProduct;

public class Test {
	public static void main(String[] args) {
		
		Buy b = new Buy();
		b.buyProduct();
		
		AddProduct a = new AddProduct();
		a.loadProduct();
		
		EditProduct e = new EditProduct();
		e.editProduct();
		
		Controle c = new Controle();
		c.getStats();
		
		
	}
}
