package com.kpmg.flipkart.owner;

public class AddProduct {
	public void loadProduct() {
		System.out.println("I am a loadProduct");
	}
}
