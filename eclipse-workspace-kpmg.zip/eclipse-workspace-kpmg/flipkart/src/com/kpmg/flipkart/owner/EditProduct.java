package com.kpmg.flipkart.owner;

public class EditProduct {
	
	public void editProduct() {
		System.out.println("I am a loadProduct");
	}
}
