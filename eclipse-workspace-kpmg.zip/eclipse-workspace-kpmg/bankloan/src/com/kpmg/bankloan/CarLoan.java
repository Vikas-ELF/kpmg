package com.kpmg.bankloan;

public class CarLoan implements Loan{

	@Override
	public void calculateEMI() {
		System.out.println("Calculating CarLoan EMI");
	}

	@Override
	public void getPremium() {
		System.out.println("Getting CarLoan Premium");
	}

}
