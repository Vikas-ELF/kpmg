package com.kpmg.bankloan;

public class HomeLoan implements Loan{

	@Override
	public void calculateEMI() {
		System.out.println("Calculating HomeLoan EMI");
	}

	@Override
	public void getPremium() {
		System.out.println("Getting HomeLoan Premium");
	}
	
	public void getDiscountUnderPm() {
		System.out.println("Getting discount under PM");
	}
	
}
