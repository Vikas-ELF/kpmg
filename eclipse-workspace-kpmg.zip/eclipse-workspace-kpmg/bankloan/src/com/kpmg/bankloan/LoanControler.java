package com.kpmg.bankloan;

public class LoanControler {
	
	public Loan getLoan(int option) {
		
		switch (option) {
		case 1:
			return new HomeLoan();
		
		case 2:
			return new PersonalLoan();
		
		case 3:
			return new CarLoan();
		
		case 4:
			return new BusinessLoan();
			
		default:
			return null;
		}
		
		/*
		if(option == 1) {
			return new HomeLoan();
		} else if(option == 2) {
			return new PersonalLoan();
		} else if(option == 3) {
			return new CarLoan();
		} else if(option == 4) {
			return new BusinessLoan();
		} else {
			return null;
		}
		*/
	}
	
}
