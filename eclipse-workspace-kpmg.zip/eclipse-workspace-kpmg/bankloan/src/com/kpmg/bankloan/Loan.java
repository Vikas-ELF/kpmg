package com.kpmg.bankloan;

public interface Loan {
	void calculateEMI();
	void getPremium();
}

