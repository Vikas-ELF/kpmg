package com.kpmg.bankloan;

public class BusinessLoan implements Loan{

	@Override
	public void calculateEMI() {
		System.out.println("Calculating BusinessLoan EMI");
	}

	@Override
	public void getPremium() {
		System.out.println("Getting BusinessLoan Premium");
	}

}
