package com.kpmg.bankloan;

public class Test {
	public static void main(String[] args) {
		
		
		LoanControler lc = new LoanControler();
		Loan h = lc.getLoan(2);
		h.getPremium();
		h.calculateEMI();
		
		if(h instanceof HomeLoan) {
			HomeLoan hm = (HomeLoan)h;
			hm.getDiscountUnderPm();
		}
	}
}
