package com.kpmg.bankloan;

public class Animal {
	
}
