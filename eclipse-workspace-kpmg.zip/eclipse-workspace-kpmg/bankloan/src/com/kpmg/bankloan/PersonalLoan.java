package com.kpmg.bankloan;

public class PersonalLoan implements Loan{

	@Override
	public void calculateEMI() {
		System.out.println("Calculating PersonalLoan EMI");
	}

	@Override
	public void getPremium() {
		System.out.println("Getting PersonalLoan Premium");
	}

}
