package com.kpmg.collection.set;

import java.util.HashSet;

public class TestA {
	public static void main(String[] args) {
		
		HashSet hs = new HashSet();
		hs.add("Anil");
		hs.add(23);
		hs.add('A');
		hs.add(9.3);
		
		for(Object r : hs) {
			System.out.println(r);
		}
		
		
	}
}
