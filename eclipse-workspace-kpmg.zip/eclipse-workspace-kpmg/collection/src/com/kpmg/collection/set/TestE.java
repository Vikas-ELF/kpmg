package com.kpmg.collection.set;

import java.util.HashSet;

public class TestE {
	public static void main(String[] args) {
		HashSet<String> hs = new HashSet<String>();
		hs.add("Meena");
		hs.add("Pinto");
		hs.add("Simran");
		hs.add("Dimple");
		hs.add("Meena");
		hs.add("Simran");
		hs.add(null);
		hs.add(null);
		
		for(String r : hs) {
			System.out.println(r);
		}
	}
}
