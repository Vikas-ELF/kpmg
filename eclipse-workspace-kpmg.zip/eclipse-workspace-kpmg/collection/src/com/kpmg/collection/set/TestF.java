package com.kpmg.collection.set;

import java.util.TreeSet;

public class TestF {
	public static void main(String[] args) {
		TreeSet ts = new TreeSet();
		ts.add(45);
		ts.add(9);
		ts.add(1);
		ts.add(6);
		
		for(Object r : ts) {
			System.out.println(r);
		}
	}
}
