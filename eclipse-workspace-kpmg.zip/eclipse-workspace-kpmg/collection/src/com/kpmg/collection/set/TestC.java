package com.kpmg.collection.set;

import java.util.HashSet;
import java.util.Iterator;

public class TestC {
	public static void main(String[] args) {
		HashSet<String> hs = new HashSet<String>();
		hs.add("Meena");
		hs.add("Pinto");
		hs.add("Simran");
		hs.add("Dimple");
		
		for(String r : hs) {
			System.out.println(r);
		}
		
		System.out.println("-----------------");
		Iterator<String> it = hs.iterator();
		while(it.hasNext()) {
			String s = it.next();
			System.out.println(s);
		}
	}
}
