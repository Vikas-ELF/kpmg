package com.kpmg.collection.set;

import java.util.LinkedHashSet;

public class TestD {
	public static void main(String[] args) {
		LinkedHashSet<String> hs = new LinkedHashSet<String>();
		hs.add("Meena");
		hs.add("Pinto");
		hs.add("Simran");
		hs.add("Dimple");
		
		for(String r : hs) {
			System.out.println(r);
		}
	}
}
