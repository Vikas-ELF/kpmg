package com.kpmg.collection.set;

import java.util.HashSet;
import java.util.Iterator;

public class TestB {
	public static void main(String[] args) {
		HashSet hs = new HashSet();
		hs.add("Anil");
		hs.add(23);
		hs.add('A');
		hs.add(9.3);
		
		Iterator it = hs.iterator();
		while(it.hasNext()) {
			Object r = it.next();
			System.out.println(r);
		}
	}
}
