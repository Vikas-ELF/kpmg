package com.kpmg.collection.example;

import java.util.HashSet;
import java.util.Iterator;

public class TestC {
	public static void main(String[] args) {
		
		
		HashSet<Employee> al = new HashSet<Employee>();
		Employee e1 = new Employee("Deepa",1,5.3);
		Employee e2 = new Employee("Anil",2,5.1);
		Employee e3 = new Employee("Raju",3,5.9);
		Employee e4 = new Employee("Pradeep",4,6.2);
		Employee e5 = new Employee("Raju",3,5.9);
		
		al.add(e1);
		al.add(e2);
		al.add(e3);
		al.add(e4);
		al.add(e5);
		
		Iterator<Employee> it = al.iterator();
		while(it.hasNext()) {
			Employee e = it.next();
			System.out.println("Name is "+e.name);
			System.out.println("Id is "+e.id);
			System.out.println("Height is "+e.height);
			System.out.println("------------------------------");
		}
		
	}
}
