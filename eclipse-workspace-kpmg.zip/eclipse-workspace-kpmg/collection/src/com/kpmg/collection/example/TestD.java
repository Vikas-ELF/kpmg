package com.kpmg.collection.example;

import java.util.List;
import java.util.ArrayList;

public class TestD {
	public static void main(String[] args) {


		List<Employee> al = new ArrayList<Employee>();

		Employee e1 = new Employee("Deepa",1,5.3);
		Employee e2 = new Employee("Anil",2,5.1);
		Employee e3 = new Employee("Raju",3,5.9);
		Employee e4 = new Employee("Pradeep",4,6.2);

		al.add(e1);
		al.add(e2);
		al.add(e3);
		al.add(e4);

		for(Employee e : al) {
			System.out.println("Name is "+e.name);
			System.out.println("Id is "+e.id);
			System.out.println("Height is "+e.height);
			System.out.println("------------------------------");
		}

	}
}
