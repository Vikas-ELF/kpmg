package com.kpmg.collection.list;

import java.util.ArrayList;

public class TestI {
	public static void main(String[] args) {
		
		ArrayList<Double> al = new ArrayList<Double>();
		al.add(2.4);
		al.add(89.3);
		al.add(5.6);
		al.add(1.9);
		al.add(10002.4);
		al.add(10001.3);
		
		ArrayList<Double> bl = new ArrayList<Double>();
		bl.add(10002.4);
		bl.add(10001.3);
		bl.add(10091.3);
		
		System.out.println("Before--->"+al);
		
		boolean res = al.containsAll(bl);
		System.out.println("Rsult is "+res);
		System.out.println("After---->"+al);
		
		
	}
}
