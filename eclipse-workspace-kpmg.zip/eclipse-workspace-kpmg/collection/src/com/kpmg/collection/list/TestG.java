package com.kpmg.collection.list;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;

public class TestG {
	public static void main(String[] args) {
		
		LinkedList<Double> al = new LinkedList<Double>();
		al.add(4.5);
		al.add(2.3);
		al.add(6.5);
		al.add(2.9);
		
		System.out.println("-------for-------");
		for(int i=0;i<al.size();i++) {
			
			Double r = al.get(i);
			System.out.println(r);
			
		}
		
		System.out.println("-------for-each-------");
		for(Double r : al) {
			System.out.println(r);
		}
		
		System.out.println("-------Iterator-------");
		Iterator<Double> it = al.iterator();
		while(it.hasNext()) {
			Double r = it.next();
			System.out.println(r);
		}
		
		System.out.println("-------ListIterator-------");
		ListIterator<Double> lit = al.listIterator();
		System.out.println("-------->Forward");
		while(lit.hasNext()) {
			Double r = lit.next();
			System.out.println(r);
		}
		
		System.out.println("<--------Backward");
		while(lit.hasPrevious()) {
			Double r = lit.previous();
			System.out.println(r);		
		}
		
		
	}
}
