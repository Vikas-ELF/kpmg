package com.kpmg.collection.list;

import java.util.LinkedList;

public class TestJ {
	public static void main(String[] args) {
		
		LinkedList<Double> al = new LinkedList<Double>();
		al.add(4.5);
		al.add(2.3);
		al.add(6.5);
		al.add(2.9);
		
		Double r = al.poll();
		System.out.println(r);
		System.out.println(al);
	}
}
