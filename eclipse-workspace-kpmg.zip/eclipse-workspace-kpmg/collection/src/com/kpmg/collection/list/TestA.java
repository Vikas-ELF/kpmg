package com.kpmg.collection.list;

import java.util.ArrayList;

public class TestA {
	public static void main(String[] args) {
		
		ArrayList al = new ArrayList();
		al.add(10);
		al.add(2.4);
		al.add('A');
		al.add("Simran");
		
		for(int i=0;i<4;i++) {
			Object r = al.get(i);
			System.out.println(r);
		}
		
		
	}
}
