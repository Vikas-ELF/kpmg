package com.kpmg.collection.list;

import java.util.ArrayList;

public class TestB {
	public static void main(String[] args) {
		ArrayList al = new ArrayList();
		al.add(10);
		al.add(2.4);
		al.add('A');
		al.add("Simran");
		
		for(Object r : al) {
			System.out.println(r);
		}
	}
}
