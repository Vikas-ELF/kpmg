package com.kpmg.collection.list;

import java.util.ArrayList;

public class TestK {
	public static void main(String[] args) {
		ArrayList<Double> al = new ArrayList<Double>();
		al.add(2.4);
		al.add(89.3);
		al.add(5.6);
		al.add(1.9);
		al.add(5.6);
		al.add(null);
		al.add(null);
		
		System.out.println(al);
	}
}
