package com.kpmg.collection.list;

import java.util.ArrayList;
import java.util.ListIterator;

public class TestD {
	public static void main(String[] args) {
		ArrayList al = new ArrayList();
		al.add(10);
		al.add(2.4);
		al.add('A');
		al.add("Simran");
		
		ListIterator lit = al.listIterator();
		System.out.println("--------->Forward");
		while(lit.hasNext()) {
			Object r = lit.next();
			System.out.println(r);
		}
		
		System.out.println("<--------Backward");
		while(lit.hasPrevious()) {
			Object r = lit.previous();
			System.out.println(r);
		}
	}
}
