package com.kpmg.collection.queq;

import java.util.PriorityQueue;

public class TestA {
	public static void main(String[] args) {
		
		
		PriorityQueue<Integer> pi = new PriorityQueue<Integer>();
		pi.add(10);
		pi.add(32);
		pi.add(22);
		pi.add(59);
		
		System.out.println(pi);
		
		pi.poll();
		
		System.out.println(pi);
		
		pi.poll();
		System.out.println(pi);
		
	}
}
