package com.kpmg.collection.map;

import java.util.HashMap;
import java.util.Map;

public class TestA {
	public static void main(String[] args) {
		
		HashMap<String, Double> hm = new HashMap<String, Double>();
		hm.put("First class", 60.00);
		hm.put("Second class", null);
		hm.put(null, 40.00);
		
		
		for(Map.Entry<String, Double> e : hm.entrySet()) {
			
			String k = e.getKey();
			Double v = e.getValue();
			
			System.out.println("Key is "+k);
			System.out.println("Value is "+v);
			System.out.println("----------------------------");
		}
		
		
		
		
	}
}
