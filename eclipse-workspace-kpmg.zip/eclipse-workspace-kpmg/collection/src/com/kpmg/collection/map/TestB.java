package com.kpmg.collection.map;

import java.util.LinkedHashMap;
import java.util.Map;

public class TestB {
	public static void main(String[] args) {
		
		LinkedHashMap<String, Double> hm = new LinkedHashMap<String, Double>();
		hm.put("First class", 60.00);
		hm.put("Second class", 50.00);
		hm.put("Third class", 40.00);
		
		
		for(Map.Entry<String, Double> e : hm.entrySet()) {
			
			String k = e.getKey();
			Double v = e.getValue();
			
			System.out.println("Key is "+k);
			System.out.println("Value is "+v);
			System.out.println("----------------------------");
		}
		
	}
}
