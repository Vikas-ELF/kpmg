package com.kpmg.collection.map;

import java.util.Hashtable;
import java.util.Map;

public class TestD {
	public static void main(String[] args) {
		Hashtable<String, Double> hm = new Hashtable<String, Double>();
		hm.put("First class", 60.00);
		hm.put("Second class", 50.00);
		hm.put("Third class", 40.00);


		for(Map.Entry<String, Double> e : hm.entrySet()) {

			String k = e.getKey();
			Double v = e.getValue();

			System.out.println("Key is "+k);
			System.out.println("Value is "+v);
			System.out.println("----------------------------");
		}
	}
}
