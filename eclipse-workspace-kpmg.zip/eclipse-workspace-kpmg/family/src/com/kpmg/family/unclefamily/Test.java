package com.kpmg.family.unclefamily;

//default ---> default,protected,public
//protected ---> protected,public
//public ---> public
class Animal {
	public void eat() {
		
	}
}

class Cow extends Animal {
	public void eat() {
		
	}
}

public class Test {

}
