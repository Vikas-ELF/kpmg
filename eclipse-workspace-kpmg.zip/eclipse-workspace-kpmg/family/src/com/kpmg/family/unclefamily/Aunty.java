package com.kpmg.family.unclefamily;

import com.kpmg.family.myfamily.Father;

public class Aunty extends Father{
	void use() {
		
		bike();
		cycle();
	}
}
