package com.kpmg.family.myfamily;

public class Son {
	void use() {
		Father f = new Father();
		f.car();
		f.bike();
		f.cycle();
	}
}
