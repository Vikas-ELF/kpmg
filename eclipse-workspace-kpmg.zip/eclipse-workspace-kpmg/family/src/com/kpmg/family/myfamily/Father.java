package com.kpmg.family.myfamily;

public class Father {
	
	private void atm() {
		System.out.println("private method atm()");
	}
	
	void car() {
		System.out.println("default method car()");
	}
	
	protected void bike() {
		System.out.println("protecetd method bike()");
	}
	
	public void cycle() {
		System.out.println("public method cycle()");
	}
	
	void use() {
		atm();
		car();
		bike();
		cycle();
	}
	
}
