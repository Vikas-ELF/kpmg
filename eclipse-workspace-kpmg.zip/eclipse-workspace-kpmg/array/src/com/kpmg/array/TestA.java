package com.kpmg.array;

public class TestA {
	public static void main(String[] args) {
		
		int[] a = new int[5];
		
		
		int b[] = new int[5];
		
		
		int []c = new int[5];
		
		
		int[] m = {10,90,34,67,3267,5362,6327,8172};
		
		
		
		
	}
}
