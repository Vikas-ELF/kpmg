package com.kpmg.array;

public class TestB {
	public static void main(String[] args) {
		
		double[] a = new double[4];
		a[0] = 9.3;
		a[1] = 3.4;
		a[2] = 5.6;
		a[3] = 9.2;
		
		
		for(double m : a) {
			System.out.println(m);
		}
		
	}
}
